export default (thing) => !!(thing && thing.Window) && (thing instanceof thing.Window);
