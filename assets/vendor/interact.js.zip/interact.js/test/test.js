import tape from 'tape';

export default tape;
