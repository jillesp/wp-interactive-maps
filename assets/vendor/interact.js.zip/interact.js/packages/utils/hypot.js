export default (x, y) =>  Math.sqrt(x * x + y * y);
